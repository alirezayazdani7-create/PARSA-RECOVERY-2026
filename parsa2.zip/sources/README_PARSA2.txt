PARSA2 COMPLETE ARTIFACT BACKUP

Includes available PARSA workflow/code/manifests/agent definitions, prior n8n backup, reports/log documents, forensic dataset/report, and Data Table schema export.

IMPORTANT: The available parsa bac deta.json contains table definitions with zero exported rows, so this archive cannot truthfully be called a full live-data backup. n8n execution history, all historical LLM call payloads/responses, and live Data Table rows are not present in the available exports.
