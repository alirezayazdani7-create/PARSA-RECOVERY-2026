# PARSA Pattern Forensic — Stages 1-2

Source: `PARSA_n8n_backup.zip`

## Inventory
- Workflows: 24
- Files: 172
- Code nodes: 78
- Explicit pattern definitions found: 8 research-cycle rules + MATH-V1 = 9
- Raw execution/trade ledger rows inside ZIP: **not present**

## Pattern registry
| ID | Pattern | Direction | Rule |
|---|---|---|---|
| P001 | VOL-SPIKE-UP | LONG | `rel_volume >= 2 AND body_ratio > 0.5` |
| P002 | VOL-SPIKE-DOWN | SHORT | `rel_volume >= 2 AND body_ratio < -0.5` |
| P003 | MOM-EXH-UP | SHORT | `mom15 > 0.02 AND dist_sma20 > 0.015` |
| P004 | MOM-EXH-DOWN | LONG | `mom15 < -0.02 AND dist_sma20 < -0.015` |
| P005 | RANGE-REV-TOP | SHORT | `range_pos > 0.95 AND upper_wick > 0.5` |
| P006 | RANGE-REV-BOT | LONG | `range_pos < 0.05 AND lower_wick > 0.5` |
| P007 | TREND-PULLBACK-LONG | LONG | `sma_ratio > 1.005 AND -0.003 < dist_sma20 < 0.003` |
| P008 | TREND-PULLBACK-SHORT | SHORT | `sma_ratio < 0.995 AND -0.003 < dist_sma20 < 0.003` |
| P009 | MATH-V1 | LONG/SHORT | `LONG: close>SMA50 + RSI cross >55 + ATR% [0.1%,3%]; SHORT: close<SMA50 + RSI cross <45 + ATR% [0.1%,3%]` |

## Feature vector
`close, volume, ret1, mom5, mom15, mom30, sma_ratio, dist_sma20, atr_pct, rel_volume, range_pos, body_ratio, upper_wick, lower_wick`

## Existing validation controls
- Temporal IS/OOS split: 70/30.
- Discovery is restricted to IS.
- Features use candles up to decision index only.
- Primary OOS/WF horizon: 15 bars.
- Cost model: 0.2% round-trip fee + 5 bps base slippage + dispersion proxy.
- Walk-forward: 3–5 windows.
- Minimum sample: 10.
- BH-FDR: q=0.05.
- Data quality gate: invalid <=1%, missing <=5%.

## Critical forensic findings
1. The backup is a **code/architecture backup**, not a historical-results database.
2. The current discovery engine is **rule-based**, not open-ended pattern mining.
3. The eight research-cycle rules are duplicated in multiple code paths; this creates configuration-drift risk.
4. `MATH-V1` is implemented separately from the pattern discovery registry.
5. Cross-asset validation is explicitly marked `NOT_TESTED` in the research-cycle FDR layer.
6. Parameter robustness is explicitly `NOT_TESTED` in the pattern-validation agent.
7. The performance-ranking layer ranks closed-position ledgers, but those ledgers are not included in this ZIP.

## Next dataset required for stages 3-7
We need the actual historical outputs/ledger rows containing at least:
`pattern_id/pattern_key, symbol, timeframe, signal_time, direction, entry, exit, outcome, fees, slippage, regime, feature_snapshot, validation_version, IS/OOS flag`.

Once those rows are available, we can compute empirical Win Rate, PF, Expectancy, MDD, OOS stability, cross-asset stability, regime dependence, and then discover Pattern+Context combinations.
